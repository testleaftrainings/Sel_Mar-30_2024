package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_LoginPage_001 extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setdata() {
		dataFile="Loginsheet1";
	}
	@Test(dataProvider = "getData")
	public void login(String user,String pass) {
		
		LoginPage lp=new LoginPage(driver);
		System.out.println(driver);
		lp.enterUserName(user).enterpassword(pass).clickOnLoginButton()
		.clickOncrmsfa();
		
	}

}
