package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;


public class MyHomePageH extends ProjectSpecficMethod{

	
	
	public HomePageH clickOncrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
 return new HomePageH();
	}

	public LoginPageH clickOnLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();

		return new LoginPageH();
	}
}
