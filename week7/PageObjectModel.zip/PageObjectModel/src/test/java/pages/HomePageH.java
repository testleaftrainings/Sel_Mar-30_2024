package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;
import base.ProjectSpecificMethod;

public class HomePageH extends ProjectSpecficMethod{
 
	
		
	public void clickLeads() {
		getDriver().findElement(By.linkText("Leads")).click();
	}
}
