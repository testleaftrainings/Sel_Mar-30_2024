package runner;

import org.testng.annotations.Test;

import base.ProjectSpecficMethod;
import pages.LoginPageH;

public class TC_002_LoginWithTestNG  extends ProjectSpecficMethod{

	@Test
	public void login() {
		
		LoginPageH lp=new LoginPageH();
		lp.enterUserName("Demosalesmanager").enterpassword("crmsfa")
		.clickOnLoginButton();
	}
	
}
