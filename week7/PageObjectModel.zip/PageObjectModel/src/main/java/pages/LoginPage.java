package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {
	
	public LoginPage(ChromeDriver driver) {
		
		this.driver=driver;
	}
	
	public LoginPage enterUserName() {
		driver.findElement(By.id("username")).sendKeys(p.getProperty("userName"));
		//m1
		//LoginPage lp =new LoginPage();
		//return lp;
		//m2
		return this;
	}
	public LoginPage enterpassword() {
		driver.findElement(By.id("password")).sendKeys(p.getProperty("password"));

		return this;
	}
	public MyHomePageH clickOnLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		
		return new MyHomePageH(driver);

	}
}
