package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecficMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageH extends ProjectSpecficMethod {
	
	
	@When("Enter the username as {string}")
	public LoginPageH enterUserName(String uname) {
		getDriver().findElement(By.id("username")).sendKeys(uname);
		return this;
	}
	
	@And("Enter the password as {string}")
	public LoginPageH enterpassword(String pass) {
		getDriver().findElement(By.id("password")).sendKeys(pass);

		return this;
	}
	
	@And("Click on LoginButton")
	public MyHomePageH clickOnLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		
		return new MyHomePageH();

	}
	
	@Then("HomePage should be displayed")
	public MyHomePageH verifythePage() {
		String text = getDriver().getTitle();
		if (text.contains("Leaftaps")) {
			System.out.println("login  not successfully");
		}
		else {
			System.out.println("login is successfully");
		}
		return new MyHomePageH();

	}


}
