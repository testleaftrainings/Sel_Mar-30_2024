package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecficMethod extends AbstractTestNGCucumberTests{

	//testng & cucumber execution -with help of ThreadLocal
	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}
	
	@BeforeMethod
	public void preCondition() {
		
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	
}	
	@AfterMethod
public void postcondition() {
		getDriver().close();
	}
}

//Loginpage-ran
//createlead-its throwing nullpointer exception

//need common driver value to all stepdef - add static keyword