package base;

public class GetPrivateData {

	public static void main(String[] args) {

		LearnThreadLocal tl=new LearnThreadLocal();
		System.out.println(tl.getCardPin());
		
	}

}
