package base;

public class LearnThreadLocal {

	private int cardPin=5647;

	public int getCardPin() {
		return cardPin;
	}

	public void setCardPin(int cardPin) {
		this.cardPin = cardPin;
	}
	
}
