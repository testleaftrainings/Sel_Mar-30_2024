package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_LoginWithPropertiesFile_003 extends ProjectSpecificMethod{

	@Test
	public void proFile() {
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName().enterpassword().clickOnLoginButton()
		.clickOncrmsfa().clickLeads();
		
	}
}
