package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecficMethod;
import pages.LoginPageH;

public class TC_002_LoginWithTestNG  extends ProjectSpecficMethod{

	@Test
	public void login() throws IOException {
		
		LoginPageH lp=new LoginPageH();
		lp.enterUserName("Demosalesmanager").enterpassword("crmsfa")
		.clickOnLoginButton();
	}
	
	@BeforeTest
	public void setValue() {
		
		testName="LoginPage";
		testDesc="Login with Valid Data";
		testAuth="Dilip";
		testCategory="Smoke";
		
	}
}
