package runner;


import base.ProjectSpecficMethod;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="src/test/java/features/Login.feature" ,
glue="pages",
publish = true,
monochrome = true)

public class TC_001_LoginWithCucumber extends ProjectSpecficMethod {

}
