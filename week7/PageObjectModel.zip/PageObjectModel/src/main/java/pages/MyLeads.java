package pages;

import base.ProjectSpecificMethod;

public class MyLeads extends ProjectSpecificMethod {

}
