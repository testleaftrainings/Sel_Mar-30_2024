package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnPropertiesFile {

	public static void main(String[] args) throws IOException {

		//step1 set path of the properties file
		FileInputStream fis=new FileInputStream("./src/main/resources/French.properties");
		
		//step 2 create object value for properties
		
		Properties pop=new Properties();
		
		//step3 -load
		pop.load(fis);
		
		//step 4 read value from properties file
		System.out.println(pop.getProperty("userName"));
		System.out.println(pop.getProperty("password"));
	}

}
