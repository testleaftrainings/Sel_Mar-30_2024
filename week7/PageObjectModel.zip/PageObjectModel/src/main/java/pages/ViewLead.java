package pages;

import base.ProjectSpecificMethod;

public class ViewLead extends ProjectSpecificMethod{

}
