package pages;

import base.ProjectSpecificMethod;

public class CreateLead extends ProjectSpecificMethod {

}
