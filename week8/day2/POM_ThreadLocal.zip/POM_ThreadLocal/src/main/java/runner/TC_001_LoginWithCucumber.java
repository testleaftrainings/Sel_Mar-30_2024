package runner;


import org.testng.annotations.BeforeTest;

import base.ProjectSpecficMethod;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="src/test/java/features/Login.feature" ,
glue="pages",
publish = true,
monochrome = true)

public class TC_001_LoginWithCucumber extends ProjectSpecficMethod {

	@BeforeTest
	public void setValue() {
		
		testName="LoginPage";
		testDesc="Login with Valid Data";
		testAuth="Dilip";
		testCategory="Smoke";
		
	}
}
