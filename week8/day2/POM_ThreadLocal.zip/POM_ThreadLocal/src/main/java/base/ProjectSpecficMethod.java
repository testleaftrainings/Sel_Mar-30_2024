package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecficMethod extends AbstractTestNGCucumberTests{
public static	ExtentReports repo;
public static ExtentTest test;
public String testName,testDesc,testAuth,testCategory;
	
	//testNG & cucumber execution -with help of ThreadLocal
	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}
	
	@BeforeMethod
	public void preCondition() {
		
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	
}	
	@AfterMethod
public void postcondition() {
		getDriver().close();
	}
	
	
	@BeforeSuite
	public void startReport() {
		
				ExtentHtmlReporter er=new ExtentHtmlReporter("./reports/Report.html");
				er.setAppendExisting(true);
			 repo=new ExtentReports();
				repo.attachReporter(er);
		
	}
	
	@AfterSuite
	public void stopReport() {
		repo.flush();
	}

	@BeforeClass
	public void testDetails() {
		
		test=repo.createTest(testName, testDesc);
		test.assignAuthor(testAuth);
		test.assignCategory(testCategory);
	}
	
	public void reportStep(String stepDetails,String status) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			test.pass(stepDetails, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			test.fail(stepDetails, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+takeSnap()+".png").build());

		}
		
		
	}
	public int takeSnap() throws IOException {
		int random = (int)(Math.random()*99999);

		File scr = getDriver().getScreenshotAs(OutputType.FILE);
		File trg=new File("./snap/img"+random+".png");
		FileUtils.copyFile(scr, trg);
		return random;
	
	}
	
}

